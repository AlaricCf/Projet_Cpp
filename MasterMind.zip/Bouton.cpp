#include "Bouton.hpp"

// Constructeur du bouton
Bouton::Bouton(){}
